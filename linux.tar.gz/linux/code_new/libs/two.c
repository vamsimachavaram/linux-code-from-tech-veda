/* lib test
 * Author : Team veda
 * */

#include <stdio.h>
test1(){
	printf(" test lib\n");
}
