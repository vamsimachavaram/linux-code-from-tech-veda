part1:	Module programming

part2:	char-skel

part3:	char-udev

part4:	char-syncr (syncr)

part5:	ioctl

part6: proc

part7:memory allocations

part8:

part9:	poll

part10:Interrupts

part11:	clock

part12:ramdisk

part13:mmap

part14:network drivers

part16:usb

part15:usb-notification

