#include<stdio.h>
int main()
{
	printf("\n\t\t*==================*");
	printf("\n\t\t   Veda Solutions");
	printf("\n\t\t*==================*\n\n");

return 0;
}
