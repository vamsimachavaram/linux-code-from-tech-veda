/* This program send the message to the appropriate mail ID
Author : IDST
Version : 1.0
*/

void pop3send()
{
	printf("\n Message sent Sucessfully");
}
