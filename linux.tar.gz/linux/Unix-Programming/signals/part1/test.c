#include <stdio.h>
main(){
	printf("in application \n");
	getchar();
}
