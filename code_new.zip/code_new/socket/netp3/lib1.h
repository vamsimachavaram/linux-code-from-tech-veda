/*  Helper Functions.
Version: 1.0
Author : Team -C
*/
# include <stdio.h>
# include <unistd.h>
# include <sys/socket.h>
# include <sys/types.h>
# include <string.h>
#include <netinet/in.h>
char * readNBytes(int , int);

int connandlisten(int);
