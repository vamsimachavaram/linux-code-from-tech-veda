#ifndef __common_h__
#define __common_h__

#define file_name "dummy_file.txt"

int setLock(int fd, int type);

#endif
