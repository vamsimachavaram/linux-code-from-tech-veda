


int somefunc(int i, int j){
	return i+j;
}
