struct node {
        int data_item1;
        int data_item2;
        struct list_head list;
};

