main()
{
	system("insmod thread.ko");

}
