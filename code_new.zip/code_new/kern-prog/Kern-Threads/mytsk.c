main()
{	
	system("echo \"Value Changed\" > /dev/pts/1");	
}
