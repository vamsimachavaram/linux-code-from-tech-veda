/* test app */

#include <stdio.h>
#include <lib.h>
int main()
{
  int i=30, j=40;
  printf("lib test\n");
//  test(i,j);
  test1();
  printf("end\n");
  return 0;
}
