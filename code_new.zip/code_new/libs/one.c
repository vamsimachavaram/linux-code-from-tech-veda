/* lib test
 * Author : Team veda
 * */

#include <stdio.h>
test(){
	printf(" test lib\n");
}
